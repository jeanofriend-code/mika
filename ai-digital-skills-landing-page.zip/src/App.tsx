import { useState, useEffect } from "react";

export default function App() {
  const [firstName, setFirstName] = useState("");
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // ── SCROLL ANIMATIONS (Mirrors your original plain JS observer) ──
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((e, i) => {
          if (e.isIntersecting) {
            setTimeout(() => e.target.classList.add("visible"), i * 80);
          }
        });
      },
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px" }
    );

    document.querySelectorAll(".fade-in").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  // ── FORM SUBMISSION (Mirrors your original plain JS handleSubmit) ──
  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    if (!firstName.trim()) {
      alert("Please enter your first name.");
      return;
    }
    if (!email.trim() || !email.includes("@")) {
      alert("Please enter a valid email address.");
      return;
    }

    setIsSubmitting(true);

    try {
      // ── BREVO / MailerLite Integration ──
      // OPTION A: BREVO (Sendinblue) — Replace YOUR_BREVO_API_KEY
      /*
      const brevoRes = await fetch('https://api.brevo.com/v3/contacts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'api-key': 'YOUR_BREVO_API_KEY'
        },
        body: JSON.stringify({
          email: email,
          attributes: { FIRSTNAME: firstName },
          listIds: [YOUR_LIST_ID],
          updateEnabled: true
        })
      });
      */

      // OPTION B: MailerLite — Replace YOUR_MAILERLITE_API_KEY and GROUP_ID
      /*
      const mlRes = await fetch('https://connect.mailerlite.com/api/subscribers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer YOUR_MAILERLITE_API_KEY'
        },
        body: JSON.stringify({
          email: email,
          fields: { name: firstName },
          groups: ['YOUR_GROUP_ID']
        })
      });
      */

      // SIMULATION (remove when API is connected)
      await new Promise((resolve) => setTimeout(resolve, 1500));

      setIsSuccess(true);

      // Track conversion (Meta Pixel)
      // if (typeof window !== 'undefined' && window.fbq) {
      //   window.fbq('track', 'Lead', { currency: 'USD', value: 0 });
      // }

      // Trigger ebook download (replace with your actual URL)
      // setTimeout(() => { window.open('YOUR_EBOOK_DOWNLOAD_URL', '_blank'); }, 1000);

    } catch (err) {
      alert("Something went wrong. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Allow Enter key submit
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSubmit();
    }
  };

  // Smooth scroll
  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const target = document.querySelector(targetId);
    if (target) {
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  return (
    <>
      {/* ── EMBEDDED ORIGINAL CSS ── */}
      <style>{`
        :root {
          --black: #030308;
          --deep: #07070f;
          --void: #0a0a16;
          --purple-dark: #1a0a2e;
          --purple: #6b21e8;
          --purple-mid: #8b3cf7;
          --purple-light: #a855f7;
          --gold: #f5c842;
          --gold-dark: #c49a0a;
          --gold-light: #fde68a;
          --neon: #00f5d4;
          --neon-purple: #bf5af2;
          --white: #f8f4ff;
          --muted: #9490a8;
          --card-bg: rgba(255,255,255,0.028);
          --card-border: rgba(107,33,232,0.22);
          --glow-purple: rgba(107,33,232,0.45);
          --glow-gold: rgba(245,200,66,0.35);
          --glow-neon: rgba(0,245,212,0.3);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body {
          background: var(--black);
          color: var(--white);
          font-family: 'Syne', sans-serif;
          overflow-x: hidden;
          cursor: default;
        }

        /* ── NOISE TEXTURE OVERLAY ── */
        body::before {
          content: '';
          position: fixed;
          inset: 0;
          background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
          pointer-events: none;
          z-index: 1000;
          opacity: 0.4;
        }

        /* ── SCROLLBAR ── */
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: var(--black); }
        ::-webkit-scrollbar-thumb { background: var(--purple); border-radius: 2px; }

        /* ── NAV ── */
        nav {
          position: fixed; top: 0; left: 0; right: 0;
          z-index: 900;
          padding: 18px 40px;
          display: flex; justify-content: space-between; align-items: center;
          background: rgba(3,3,8,0.85);
          backdrop-filter: blur(20px);
          border-bottom: 1px solid rgba(107,33,232,0.15);
        }
        .nav-logo {
          font-family: 'Orbitron', monospace;
          font-size: 13px; letter-spacing: 3px;
          color: var(--gold);
          text-transform: uppercase;
        }
        .nav-cta {
          font-size: 12px; letter-spacing: 2px;
          padding: 10px 22px;
          background: linear-gradient(135deg, var(--purple), var(--purple-light));
          border: none; border-radius: 4px;
          color: #fff; cursor: pointer;
          font-family: 'Syne', sans-serif; font-weight: 600;
          text-transform: uppercase;
          transition: all 0.3s;
          text-decoration: none;
        }
        .nav-cta:hover { box-shadow: 0 0 24px var(--glow-purple); transform: translateY(-1px); }

        /* ── HERO ── */
        #hero {
          min-height: 100vh;
          display: flex; align-items: center;
          position: relative;
          overflow: hidden;
          padding: 120px 40px 80px;
        }

        .hero-grid-bg {
          position: absolute; inset: 0;
          background-image:
            linear-gradient(rgba(107,33,232,0.07) 1px, transparent 1px),
            linear-gradient(90deg, rgba(107,33,232,0.07) 1px, transparent 1px);
          background-size: 60px 60px;
          mask-image: radial-gradient(ellipse 70% 70% at 50% 50%, black, transparent);
        }

        .hero-orb-1 {
          position: absolute; width: 600px; height: 600px;
          background: radial-gradient(circle, rgba(107,33,232,0.18) 0%, transparent 70%);
          top: -100px; right: -100px; border-radius: 50%;
          animation: orb-drift 8s ease-in-out infinite alternate;
        }
        .hero-orb-2 {
          position: absolute; width: 400px; height: 400px;
          background: radial-gradient(circle, rgba(0,245,212,0.1) 0%, transparent 70%);
          bottom: -50px; left: 10%; border-radius: 50%;
          animation: orb-drift 12s ease-in-out infinite alternate-reverse;
        }
        @keyframes orb-drift {
          from { transform: translate(0,0) scale(1); }
          to { transform: translate(30px,20px) scale(1.05); }
        }

        .hero-inner {
          max-width: 1200px; margin: 0 auto; width: 100%;
          display: grid; grid-template-columns: 1fr 420px; gap: 80px; align-items: center;
          position: relative; z-index: 2;
        }

        .hero-eyebrow {
          display: inline-flex; align-items: center; gap: 8px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px; letter-spacing: 3px; color: var(--neon);
          text-transform: uppercase;
          padding: 8px 16px;
          background: rgba(0,245,212,0.08);
          border: 1px solid rgba(0,245,212,0.2);
          border-radius: 2px;
          margin-bottom: 28px;
          animation: fadeUp 0.8s ease both;
        }
        .hero-eyebrow::before { content: '◆'; font-size: 8px; }

        .hero-h1 {
          font-family: 'Orbitron', monospace;
          font-size: clamp(32px, 4.5vw, 62px);
          font-weight: 900;
          line-height: 1.08;
          letter-spacing: -1px;
          margin-bottom: 24px;
          animation: fadeUp 0.9s 0.1s ease both;
        }
        .hero-h1 .gold {
          background: linear-gradient(135deg, var(--gold), var(--gold-light), var(--gold));
          -webkit-background-clip: text; -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        .hero-h1 .purple { color: var(--purple-light); }

        .hero-sub {
          font-size: clamp(15px, 1.6vw, 18px);
          color: rgba(248,244,255,0.65);
          line-height: 1.7;
          max-width: 540px;
          margin-bottom: 40px;
          font-weight: 400;
          animation: fadeUp 0.9s 0.2s ease both;
        }

        .hero-cta-wrap {
          display: flex; flex-direction: column; gap: 16px; align-items: flex-start;
          animation: fadeUp 0.9s 0.3s ease both;
        }

        .btn-primary {
          display: inline-flex; align-items: center; gap: 12px;
          padding: 18px 40px;
          background: linear-gradient(135deg, #7c3aed, #a855f7, #7c3aed);
          background-size: 200% 200%;
          border: 1px solid rgba(168,85,247,0.4);
          border-radius: 6px;
          color: #fff;
          font-family: 'Orbitron', monospace;
          font-size: 13px; font-weight: 700; letter-spacing: 2px;
          text-transform: uppercase;
          cursor: pointer; text-decoration: none;
          position: relative; overflow: hidden;
          transition: all 0.3s;
          animation: bg-shift 3s linear infinite;
        }
        @keyframes bg-shift {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .btn-primary::before {
          content: ''; position: absolute; inset: 0;
          background: linear-gradient(135deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%);
          transform: translateX(-100%);
          transition: transform 0.5s;
        }
        .btn-primary:hover::before { transform: translateX(100%); }
        .btn-primary:hover {
          box-shadow: 0 0 40px var(--glow-purple), 0 0 80px rgba(107,33,232,0.2);
          transform: translateY(-2px);
        }
        .btn-arrow { font-size: 18px; transition: transform 0.3s; }
        .btn-primary:hover .btn-arrow { transform: translateX(4px); }

        .trust-badge {
          display: flex; align-items: center; gap: 8px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px; letter-spacing: 1.5px; color: var(--muted);
        }
        .trust-dot {
          width: 6px; height: 6px; border-radius: 50%;
          background: var(--neon);
          box-shadow: 0 0 8px var(--neon);
          animation: pulse-dot 2s ease infinite;
        }
        @keyframes pulse-dot {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.5); opacity: 0.6; }
        }

        /* ── EBOOK MOCKUP ── */
        .hero-visual {
          display: flex; justify-content: center; align-items: center;
          animation: fadeUp 1s 0.4s ease both;
        }

        .book-wrapper {
          position: relative;
          width: 280px;
          animation: float 4s ease-in-out infinite;
        }
        @keyframes float {
          0%, 100% { transform: translateY(0) rotateY(-8deg); }
          50% { transform: translateY(-18px) rotateY(-5deg); }
        }

        .book-3d {
          width: 280px;
          border-radius: 6px 16px 16px 6px;
          position: relative;
          transform-style: preserve-3d;
          perspective: 800px;
        }

        .book-cover {
          width: 100%;
          aspect-ratio: 3/4;
          border-radius: 4px 12px 12px 4px;
          background: linear-gradient(145deg, #0f0020, #1a0035, #0d001a);
          border: 1px solid rgba(107,33,232,0.5);
          position: relative;
          overflow: hidden;
          box-shadow:
            -8px 0 0 rgba(0,0,0,0.4),
            0 20px 60px rgba(107,33,232,0.4),
            0 0 0 1px rgba(245,200,66,0.15),
            inset 0 0 80px rgba(107,33,232,0.15);
        }

        .book-cover-inner {
          position: absolute; inset: 0;
          display: flex; flex-direction: column;
          padding: 24px 20px 20px;
        }

        .book-hex-grid {
          position: absolute; inset: 0; opacity: 0.12;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='28' height='32'%3E%3Cpath d='M14 2L26 9v14L14 30 2 23V9z' fill='none' stroke='%23a855f7' stroke-width='0.5'/%3E%3C/svg%3E");
          background-size: 28px 32px;
        }

        .book-orb {
          position: absolute;
          width: 180px; height: 180px;
          background: radial-gradient(circle, rgba(107,33,232,0.6) 0%, transparent 70%);
          top: 50%; left: 50%; transform: translate(-50%,-50%);
          border-radius: 50%;
        }

        .book-badge {
          font-family: 'JetBrains Mono', monospace;
          font-size: 7px; letter-spacing: 3px;
          color: var(--gold); text-transform: uppercase;
          background: rgba(245,200,66,0.1);
          border: 1px solid rgba(245,200,66,0.3);
          padding: 4px 10px;
          border-radius: 2px;
          width: fit-content;
          margin-bottom: 8px;
          position: relative; z-index: 2;
        }

        .book-icon {
          font-size: 42px; margin-bottom: 8px;
          position: relative; z-index: 2;
          filter: drop-shadow(0 0 16px rgba(107,33,232,0.8));
          text-align: center;
        }

        .book-title {
          font-family: 'Orbitron', monospace;
          font-size: 14px; font-weight: 900;
          color: var(--white);
          line-height: 1.2;
          letter-spacing: 1px;
          text-transform: uppercase;
          position: relative; z-index: 2;
          margin-bottom: 6px;
          text-shadow: 0 0 20px rgba(168,85,247,0.8);
        }
        .book-title .t-gold {
          color: var(--gold);
          text-shadow: 0 0 20px rgba(245,200,66,0.6);
        }

        .book-subtitle {
          font-size: 8px; letter-spacing: 2px;
          color: rgba(168,85,247,0.85);
          text-transform: uppercase;
          position: relative; z-index: 2;
          margin-bottom: auto;
        }

        .book-bottom {
          display: flex; justify-content: space-between; align-items: flex-end;
          position: relative; z-index: 2;
        }
        .book-free {
          font-family: 'Orbitron', monospace;
          font-size: 20px; font-weight: 900;
          color: var(--gold);
          text-shadow: 0 0 20px var(--gold-dark);
        }
        .book-stars { font-size: 9px; color: var(--gold); letter-spacing: 1px; }
        .book-reviews { font-size: 7px; color: var(--muted); letter-spacing: 1px; }

        .book-spine {
          position: absolute;
          left: -8px; top: 0;
          width: 8px; height: 100%;
          background: linear-gradient(180deg, #2d1060, #1a0035, #2d1060);
          border-radius: 3px 0 0 3px;
          border: 1px solid rgba(107,33,232,0.3);
          border-right: none;
        }

        .book-glow {
          position: absolute; inset: -20px;
          background: radial-gradient(ellipse at center, rgba(107,33,232,0.25) 0%, transparent 70%);
          pointer-events: none;
          z-index: -1;
        }

        /* ── SECTION BASE ── */
        section { padding: 100px 40px; position: relative; }
        .section-inner { max-width: 1200px; margin: 0 auto; }

        .section-label {
          font-family: 'JetBrains Mono', monospace;
          font-size: 10px; letter-spacing: 4px; color: var(--neon);
          text-transform: uppercase;
          display: flex; align-items: center; gap: 12px;
          margin-bottom: 16px;
        }
        .section-label::after {
          content: ''; flex: 1; max-width: 60px; height: 1px;
          background: linear-gradient(90deg, var(--neon), transparent);
        }

        .section-title {
          font-family: 'Orbitron', monospace;
          font-size: clamp(24px, 3.5vw, 42px);
          font-weight: 800;
          line-height: 1.15;
          margin-bottom: 16px;
        }
        .section-title .hl {
          background: linear-gradient(135deg, var(--purple-light), var(--neon-purple));
          -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }
        .section-title .hl-gold {
          background: linear-gradient(135deg, var(--gold), var(--gold-light));
          -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text;
        }

        .section-sub {
          font-size: 16px; color: rgba(248,244,255,0.55);
          line-height: 1.7; max-width: 560px;
          margin-bottom: 60px;
        }

        /* ── DIVIDER ── */
        .divider {
          height: 1px;
          background: linear-gradient(90deg, transparent, rgba(107,33,232,0.4), rgba(245,200,66,0.3), rgba(107,33,232,0.4), transparent);
          margin: 0 40px;
        }

        /* ── URGENCY BANNER ── */
        #urgency {
          padding: 28px 40px;
          background: linear-gradient(135deg, rgba(245,200,66,0.07), rgba(107,33,232,0.07));
          border-top: 1px solid rgba(245,200,66,0.2);
          border-bottom: 1px solid rgba(245,200,66,0.2);
        }
        .urgency-inner {
          max-width: 1200px; margin: 0 auto;
          display: flex; align-items: center; gap: 20px;
          flex-wrap: wrap;
        }
        .urgency-icon { font-size: 28px; animation: pulse-dot 2s ease infinite; }
        .urgency-text {
          font-family: 'Syne', sans-serif;
          font-size: 16px; font-weight: 600;
          color: var(--gold-light);
          line-height: 1.5;
        }
        .urgency-text span { color: var(--white); }
        .urgency-bar {
          flex: 1; height: 3px; min-width: 80px;
          background: linear-gradient(90deg, var(--gold), transparent);
          border-radius: 2px;
        }

        /* ── LEARN CARDS ── */
        #learn {
          background: linear-gradient(180deg, var(--black) 0%, var(--void) 100%);
        }

        .cards-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
          gap: 20px;
        }

        .learn-card {
          padding: 28px;
          background: var(--card-bg);
          border: 1px solid var(--card-border);
          border-radius: 12px;
          position: relative; overflow: hidden;
          transition: all 0.3s;
          cursor: default;
        }
        .learn-card::before {
          content: '';
          position: absolute; top: 0; left: 0; right: 0; height: 1px;
          background: linear-gradient(90deg, transparent, var(--purple-light), transparent);
          opacity: 0; transition: opacity 0.3s;
        }
        .learn-card:hover {
          border-color: rgba(107,33,232,0.5);
          transform: translateY(-4px);
          box-shadow: 0 16px 48px rgba(107,33,232,0.15);
        }
        .learn-card:hover::before { opacity: 1; }

        .card-icon {
          font-size: 36px; margin-bottom: 16px;
          display: block;
          filter: drop-shadow(0 0 10px rgba(107,33,232,0.6));
        }
        .card-title {
          font-family: 'Orbitron', monospace;
          font-size: 13px; font-weight: 700;
          letter-spacing: 1px;
          margin-bottom: 10px;
          color: var(--white);
        }
        .card-desc {
          font-size: 14px; line-height: 1.65;
          color: rgba(248,244,255,0.5);
        }
        .card-tag {
          display: inline-block; margin-top: 14px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 9px; letter-spacing: 2px;
          color: var(--neon);
          background: rgba(0,245,212,0.07);
          border: 1px solid rgba(0,245,212,0.15);
          padding: 4px 10px; border-radius: 2px;
        }

        /* ── INSIDE EBOOK ── */
        #inside {
          background: var(--void);
        }

        .inside-wrap {
          display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;
        }

        .checklist { display: flex; flex-direction: column; gap: 0; }

        .check-item {
          display: flex; align-items: flex-start; gap: 16px;
          padding: 20px 0;
          border-bottom: 1px solid rgba(107,33,232,0.12);
          transition: all 0.3s;
        }
        .check-item:last-child { border-bottom: none; }
        .check-item:hover .check-icon { transform: scale(1.1); }

        .check-icon {
          width: 36px; height: 36px; flex-shrink: 0;
          background: linear-gradient(135deg, rgba(107,33,232,0.2), rgba(168,85,247,0.1));
          border: 1px solid rgba(107,33,232,0.35);
          border-radius: 8px;
          display: flex; align-items: center; justify-content: center;
          font-size: 16px;
          transition: transform 0.3s;
        }
        .check-title {
          font-family: 'Syne', sans-serif;
          font-size: 15px; font-weight: 700;
          color: var(--white); margin-bottom: 4px;
        }
        .check-desc {
          font-size: 13px; line-height: 1.6;
          color: rgba(248,244,255,0.45);
        }

        .inside-visual {
          position: relative;
          display: flex; justify-content: center;
        }

        .inside-card-stack {
          position: relative; width: 320px; height: 380px;
        }
        .icard {
          position: absolute;
          width: 280px; padding: 24px;
          background: linear-gradient(135deg, rgba(26,10,46,0.9), rgba(7,7,15,0.9));
          border: 1px solid rgba(107,33,232,0.3);
          border-radius: 16px;
          backdrop-filter: blur(10px);
        }
        .icard:nth-child(1) { top: 0; left: 20px; transform: rotate(-4deg); }
        .icard:nth-child(2) { top: 30px; left: 0; transform: rotate(0deg); z-index: 2; border-color: rgba(245,200,66,0.3); }
        .icard:nth-child(3) { top: 60px; left: 40px; transform: rotate(3deg); }

        .icard-label {
          font-family: 'JetBrains Mono', monospace;
          font-size: 9px; letter-spacing: 3px; color: var(--gold);
          text-transform: uppercase; margin-bottom: 12px;
        }
        .icard-number {
          font-family: 'Orbitron', monospace;
          font-size: 48px; font-weight: 900;
          color: var(--purple-light);
          opacity: 0.3;
          line-height: 1;
        }
        .icard-text {
          font-size: 18px; font-weight: 700;
          color: var(--white); margin-top: -8px;
        }

        /* ── BENEFITS ── */
        #benefits {
          background: linear-gradient(180deg, var(--void), var(--black));
        }

        .benefits-grid {
          display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px;
        }

        .benefit-item {
          display: flex; align-items: flex-start; gap: 20px;
          padding: 28px;
          background: var(--card-bg);
          border: 1px solid rgba(107,33,232,0.15);
          border-radius: 12px;
          transition: all 0.3s;
        }
        .benefit-item:hover {
          border-color: rgba(245,200,66,0.25);
          box-shadow: 0 8px 32px rgba(245,200,66,0.05);
        }
        .benefit-num {
          font-family: 'Orbitron', monospace;
          font-size: 24px; font-weight: 900;
          color: var(--gold);
          opacity: 0.4;
          flex-shrink: 0;
          line-height: 1;
          width: 40px;
          text-align: right;
        }
        .benefit-title {
          font-size: 16px; font-weight: 700;
          color: var(--white); margin-bottom: 6px;
        }
        .benefit-desc {
          font-size: 13px; line-height: 1.65;
          color: rgba(248,244,255,0.45);
        }

        /* ── EMAIL FORM ── */
        #signup {
          background: var(--black);
          position: relative; overflow: hidden;
        }
        #signup::before {
          content: '';
          position: absolute; inset: 0;
          background: radial-gradient(ellipse 60% 80% at 50% 50%, rgba(107,33,232,0.08) 0%, transparent 70%);
        }

        .form-container {
          max-width: 560px; margin: 0 auto;
          position: relative; z-index: 2;
          text-align: center;
        }

        .form-box {
          margin-top: 48px;
          padding: 48px 40px;
          background: rgba(255,255,255,0.03);
          border: 1px solid rgba(107,33,232,0.3);
          border-radius: 20px;
          position: relative;
          overflow: hidden;
        }
        .form-box::before {
          content: '';
          position: absolute; top: 0; left: 0; right: 0; height: 2px;
          background: linear-gradient(90deg, transparent, var(--purple), var(--gold), var(--purple), transparent);
        }

        .form-title {
          font-family: 'Orbitron', monospace;
          font-size: 22px; font-weight: 800;
          margin-bottom: 8px;
        }
        .form-sub { font-size: 14px; color: var(--muted); margin-bottom: 32px; line-height: 1.6; }

        .form-group { margin-bottom: 16px; text-align: left; }
        .form-group label {
          display: block;
          font-family: 'JetBrains Mono', monospace;
          font-size: 10px; letter-spacing: 2px; color: var(--muted);
          text-transform: uppercase; margin-bottom: 8px;
        }
        .form-group input {
          width: 100%;
          padding: 16px 20px;
          background: rgba(255,255,255,0.04);
          border: 1px solid rgba(107,33,232,0.25);
          border-radius: 8px;
          color: var(--white);
          font-family: 'Syne', sans-serif;
          font-size: 15px;
          outline: none;
          transition: all 0.3s;
        }
        .form-group input::placeholder { color: rgba(148,144,168,0.4); }
        .form-group input:focus {
          border-color: var(--purple-light);
          box-shadow: 0 0 0 3px rgba(107,33,232,0.12);
        }

        .btn-submit {
          width: 100%;
          padding: 18px;
          background: linear-gradient(135deg, var(--gold-dark), var(--gold), var(--gold-light), var(--gold));
          background-size: 200% 200%;
          border: none; border-radius: 8px;
          color: #0a0a0a;
          font-family: 'Orbitron', monospace;
          font-size: 13px; font-weight: 900;
          letter-spacing: 2px; text-transform: uppercase;
          cursor: pointer;
          margin-top: 8px;
          transition: all 0.3s;
          animation: bg-shift 4s linear infinite;
          position: relative; overflow: hidden;
        }
        .btn-submit:hover {
          box-shadow: 0 0 40px var(--glow-gold);
          transform: translateY(-2px);
        }
        .btn-submit:disabled { opacity: 0.6; cursor: not-allowed; transform: none; }

        .form-privacy {
          margin-top: 16px;
          font-size: 11px; color: rgba(148,144,168,0.4);
          line-height: 1.6;
        }

        /* ── SUCCESS STATE ── */
        .success-message {
          text-align: center; padding: 48px 24px;
          animation: fadeUp 0.6s ease both;
        }
        .success-icon { font-size: 56px; margin-bottom: 20px; animation: bounce 1s ease; }
        @keyframes bounce { 0%, 100% { transform: scale(1); } 50% { transform: scale(1.2); } }
        .success-title {
          font-family: 'Orbitron', monospace;
          font-size: 22px; font-weight: 800; color: var(--gold);
          margin-bottom: 12px;
        }
        .success-sub { font-size: 15px; color: var(--muted); line-height: 1.7; margin-bottom: 24px; }
        .success-steps {
          display: flex; flex-direction: column; gap: 12px;
          text-align: left;
        }
        .sstep {
          display: flex; align-items: center; gap: 12px;
          padding: 14px 16px;
          background: rgba(0,245,212,0.05);
          border: 1px solid rgba(0,245,212,0.15);
          border-radius: 8px;
          font-size: 13px; color: rgba(248,244,255,0.7);
        }
        .sstep-icon { font-size: 18px; }

        /* ── EMAIL SEQUENCE ── */
        #sequence {
          background: var(--void);
        }

        .sequence-line {
          display: flex;
          flex-direction: column;
          gap: 0;
          position: relative;
          padding-left: 60px;
        }
        .sequence-line::before {
          content: '';
          position: absolute; left: 23px; top: 24px; bottom: 24px; width: 2px;
          background: linear-gradient(180deg, var(--purple), rgba(107,33,232,0.1));
        }

        .seq-item {
          display: flex; align-items: flex-start; gap: 24px;
          padding: 28px 0;
          position: relative;
        }

        .seq-dot {
          position: absolute; left: -49px; top: 30px;
          width: 20px; height: 20px;
          background: var(--black);
          border: 2px solid var(--purple);
          border-radius: 50%;
          display: flex; align-items: center; justify-content: center;
          font-size: 8px; color: var(--purple-light);
          font-family: 'JetBrains Mono', monospace;
          flex-shrink: 0;
        }
        .seq-dot.active {
          border-color: var(--gold);
          color: var(--gold);
          box-shadow: 0 0 12px rgba(245,200,66,0.4);
        }

        .seq-content {
          flex: 1;
          padding: 24px;
          background: var(--card-bg);
          border: 1px solid var(--card-border);
          border-radius: 12px;
          transition: all 0.3s;
        }
        .seq-content:hover { border-color: rgba(107,33,232,0.4); }

        .seq-timing {
          font-family: 'JetBrains Mono', monospace;
          font-size: 9px; letter-spacing: 2px; color: var(--neon);
          text-transform: uppercase; margin-bottom: 8px;
        }
        .seq-title {
          font-family: 'Syne', sans-serif;
          font-size: 16px; font-weight: 700; color: var(--white);
          margin-bottom: 6px;
        }
        .seq-desc { font-size: 13px; color: var(--muted); line-height: 1.6; }
        .seq-tag {
          display: inline-block; margin-top: 12px;
          font-size: 9px; letter-spacing: 1px;
          padding: 3px 10px; border-radius: 2px;
          font-family: 'JetBrains Mono', monospace;
        }
        .seq-tag.delivery { background: rgba(0,245,212,0.08); border: 1px solid rgba(0,245,212,0.2); color: var(--neon); }
        .seq-tag.value { background: rgba(107,33,232,0.08); border: 1px solid rgba(107,33,232,0.25); color: var(--purple-light); }
        .seq-tag.promo { background: rgba(245,200,66,0.08); border: 1px solid rgba(245,200,66,0.25); color: var(--gold); }

        /* ── SOCIAL PROOF ── */
        #proof { background: var(--black); }

        .testimonials {
          display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 20px;
        }

        .tcard {
          padding: 28px;
          background: var(--card-bg);
          border: 1px solid var(--card-border);
          border-radius: 14px;
          position: relative;
          transition: all 0.3s;
        }
        .tcard:hover {
          border-color: rgba(107,33,232,0.4);
          transform: translateY(-3px);
        }
        .tcard-quote {
          font-family: 'JetBrains Mono', monospace;
          font-size: 32px; color: var(--purple);
          line-height: 1; margin-bottom: 12px;
          opacity: 0.5;
        }
        .tcard-text {
          font-size: 14px; line-height: 1.75;
          color: rgba(248,244,255,0.7);
          margin-bottom: 20px;
        }
        .tcard-author {
          display: flex; align-items: center; gap: 12px;
        }
        .tcard-avatar {
          width: 40px; height: 40px; border-radius: 50%;
          background: linear-gradient(135deg, var(--purple), var(--purple-light));
          display: flex; align-items: center; justify-content: center;
          font-size: 16px;
          flex-shrink: 0;
        }
        .tcard-name {
          font-weight: 700; font-size: 14px; color: var(--white);
        }
        .tcard-role { font-size: 11px; color: var(--muted); margin-top: 2px; }
        .tcard-stars {
          position: absolute; top: 24px; right: 24px;
          color: var(--gold); font-size: 11px; letter-spacing: 2px;
        }

        /* ── FINAL CTA ── */
        #finalcta {
          background: linear-gradient(135deg, var(--void), var(--purple-dark), var(--void));
          text-align: center;
          position: relative; overflow: hidden;
        }
        #finalcta::before {
          content: '';
          position: absolute; inset: 0;
          background: radial-gradient(ellipse 50% 80% at 50% 50%, rgba(107,33,232,0.15) 0%, transparent 70%);
        }

        .final-inner {
          position: relative; z-index: 2;
          max-width: 700px; margin: 0 auto;
        }

        .final-h2 {
          font-family: 'Orbitron', monospace;
          font-size: clamp(28px, 4vw, 52px);
          font-weight: 900;
          line-height: 1.1;
          margin-bottom: 24px;
        }

        .final-sub {
          font-size: 17px; color: rgba(248,244,255,0.6);
          line-height: 1.7; margin-bottom: 48px;
        }

        .btn-final {
          display: inline-flex; align-items: center; gap: 14px;
          padding: 22px 52px;
          background: linear-gradient(135deg, var(--gold-dark), var(--gold), var(--gold-light));
          border: none; border-radius: 8px;
          color: #0a0a0a;
          font-family: 'Orbitron', monospace;
          font-size: 14px; font-weight: 900; letter-spacing: 2px;
          text-transform: uppercase;
          cursor: pointer; text-decoration: none;
          transition: all 0.3s;
          position: relative; overflow: hidden;
        }
        .btn-final:hover {
          box-shadow: 0 0 60px var(--glow-gold), 0 0 120px rgba(245,200,66,0.1);
          transform: translateY(-3px);
        }
        .btn-final::before {
          content: ''; position: absolute; inset: 0;
          background: linear-gradient(135deg, transparent 30%, rgba(255,255,255,0.2) 50%, transparent 70%);
          transform: translateX(-100%); transition: transform 0.5s;
        }
        .btn-final:hover::before { transform: translateX(100%); }

        .final-note {
          margin-top: 24px;
          font-family: 'JetBrains Mono', monospace;
          font-size: 11px; letter-spacing: 2px;
          color: rgba(148,144,168,0.4);
        }
        .final-features {
          display: flex; justify-content: center; gap: 32px;
          flex-wrap: wrap;
          margin-top: 40px;
        }
        .ff-item {
          display: flex; align-items: center; gap: 8px;
          font-size: 13px; color: rgba(248,244,255,0.45);
        }
        .ff-check { color: var(--neon); font-size: 14px; }

        /* ── FOOTER ── */
        footer {
          padding: 32px 40px;
          border-top: 1px solid rgba(107,33,232,0.12);
          display: flex; justify-content: space-between; align-items: center;
          flex-wrap: wrap; gap: 16px;
        }
        .footer-logo {
          font-family: 'Orbitron', monospace;
          font-size: 11px; letter-spacing: 3px; color: var(--purple-light);
        }
        .footer-links { display: flex; gap: 24px; }
        .footer-links a {
          font-size: 11px; color: var(--muted); text-decoration: none;
          transition: color 0.3s; letter-spacing: 1px;
        }
        .footer-links a:hover { color: var(--purple-light); }
        .footer-copy { font-size: 11px; color: rgba(148,144,168,0.3); }

        /* ── ANIMATIONS ── */
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(30px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .fade-in {
          opacity: 0; transform: translateY(24px);
          transition: opacity 0.7s ease, transform 0.7s ease;
        }
        .fade-in.visible { opacity: 1; transform: translateY(0); }

        /* ── MOBILE ── */
        @media(max-width: 900px) {
          nav { padding: 16px 20px; }
          .nav-cta { display: none; }
          #hero { padding: 100px 20px 60px; }
          .hero-inner { grid-template-columns: 1fr; gap: 48px; text-align: center; }
          .hero-cta-wrap { align-items: center; }
          .hero-sub { max-width: 100%; }
          .hero-visual { order: -1; }
          section { padding: 70px 20px; }
          .inside-wrap { grid-template-columns: 1fr; }
          .inside-visual { display: none; }
          .sequence-line { padding-left: 48px; }
          footer { flex-direction: column; gap: 12px; text-align: center; }
          .footer-links { justify-content: center; }
          .final-features { gap: 16px; }
        }
        @media(max-width: 600px) {
          .form-box { padding: 32px 20px; }
          .urgency-inner { justify-content: center; text-align: center; }
          .urgency-bar { display: none; }
        }
      `}</style>

      {/* NAV */}
      <nav>
        <div className="nav-logo">AI Income System</div>
        <a href="#signup" onClick={(e) => scrollToSection(e, "#signup")} className="nav-cta">
          Get Free Access
        </a>
      </nav>

      {/* HERO */}
      <section id="hero">
        <div className="hero-grid-bg"></div>
        <div className="hero-orb-1"></div>
        <div className="hero-orb-2"></div>
        <div className="hero-inner">
          <div className="hero-text">
            <div className="hero-eyebrow">Free Ebook — 2026 Edition</div>
            <h1 className="hero-h1">
              Learn <span className="gold">AI Digital Skills</span>
              <br />
              That Can <span className="purple">Make You Money</span>
              <br />
              in 2026
            </h1>
            <p className="hero-sub">
              Discover step-by-step AI systems, monetization strategies, tools, and income blueprints designed for beginners. No experience needed.
            </p>
            <div className="hero-cta-wrap">
              <a href="#signup" onClick={(e) => scrollToSection(e, "#signup")} className="btn-primary">
                Get Instant Access <span className="btn-arrow">→</span>
              </a>
              <div className="trust-badge">
                <span className="trust-dot"></span>
                No experience needed · 100% Free · Instant Download
              </div>
            </div>
          </div>
          <div className="hero-visual">
            <div className="book-wrapper">
              <div className="book-glow"></div>
              <div className="book-3d">
                <div className="book-spine"></div>
                <div className="book-cover">
                  <div className="book-hex-grid"></div>
                  <div className="book-orb"></div>
                  <div className="book-cover-inner">
                    <div className="book-badge">◆ 2026 Edition</div>
                    <div className="book-icon">🤖</div>
                    <div className="book-title">
                      <span className="t-gold">AI DIGITAL</span>
                      <br />
                      SKILLS TO
                      <br />
                      MAKE MONEY
                    </div>
                    <div className="book-subtitle">The Complete AI Income System</div>
                    <div className="book-bottom">
                      <div>
                        <div className="book-free">FREE</div>
                        <div className="book-reviews">Instant Download</div>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div className="book-stars">★★★★★</div>
                        <div className="book-reviews">4.9 / 5 Rating</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* URGENCY */}
      <div id="urgency">
        <div className="urgency-inner">
          <span className="urgency-icon">⚡</span>
          <p className="urgency-text">
            <span>AI is changing digital business fast.</span> Learn the skills now before the market becomes overcrowded — the window to build a competitive edge is closing.
          </p>
          <div className="urgency-bar"></div>
        </div>
      </div>

      <div className="divider"></div>

      {/* WHAT YOU'LL LEARN */}
      <section id="learn">
        <div className="section-inner">
          <div className="section-label fade-in">What You'll Learn</div>
          <h2 className="section-title fade-in">
            7 <span className="hl">AI Skill Areas</span> That
            <br />
            Generate Real Income
          </h2>
          <p className="section-sub fade-in">Each module is engineered for action — not theory. Learn, implement, earn.</p>
          <div className="cards-grid">
            <div className="learn-card fade-in">
              <span className="card-icon">💰</span>
              <div className="card-title">AI Tools That Make Money</div>
              <div className="card-desc">Discover the exact AI platforms that professionals use to generate income — from writing tools to image generators and automation apps.</div>
              <span className="card-tag">MONETIZATION</span>
            </div>
            <div className="learn-card fade-in">
              <span className="card-icon">🎨</span>
              <div className="card-title">Content Creation with AI</div>
              <div className="card-desc">Create scroll-stopping content 10x faster using AI. Build blogs, videos, social posts, and graphics that attract an audience and clients.</div>
              <span className="card-tag">CONTENT</span>
            </div>
            <div className="learn-card fade-in">
              <span className="card-icon">⚙️</span>
              <div className="card-title">AI Monetization Systems</div>
              <div className="card-desc">Build repeatable income systems using AI — digital products, services, subscriptions, and affiliate pipelines that scale without you.</div>
              <span className="card-tag">SYSTEMS</span>
            </div>
            <div className="learn-card fade-in">
              <span className="card-icon">💼</span>
              <div className="card-title">Freelancing with AI</div>
              <div className="card-desc">Land high-paying freelance clients by offering AI-powered services. Learn how to price, package, and deliver value faster than the competition.</div>
              <span className="card-tag">FREELANCE</span>
            </div>
            <div className="learn-card fade-in">
              <span className="card-icon">🔄</span>
              <div className="card-title">Automation Workflows</div>
              <div className="card-desc">Design automated pipelines that do the heavy lifting. Connect AI tools to eliminate repetitive tasks and unlock more productive hours.</div>
              <span className="card-tag">AUTOMATION</span>
            </div>
            <div className="learn-card fade-in">
              <span className="card-icon">📱</span>
              <div className="card-title">Social Media Growth</div>
              <div className="card-desc">Master AI-powered social strategies to grow an engaged audience across TikTok, Instagram, YouTube, and LinkedIn — and monetize that growth.</div>
              <span className="card-tag">GROWTH</span>
            </div>
            <div className="learn-card fade-in">
              <span className="card-icon">🌐</span>
              <div className="card-title">Digital Income Strategies</div>
              <div className="card-desc">Explore 10+ proven digital income models — from selling prompts and templates to building AI-powered SaaS micro-tools and info products.</div>
              <span className="card-tag">INCOME</span>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* WHAT'S INSIDE */}
      <section id="inside">
        <div className="section-inner">
          <div className="inside-wrap">
            <div>
              <div className="section-label fade-in">What's Inside</div>
              <h2 className="section-title fade-in">
                Everything You Need to
                <br />
                <span className="hl-gold">Start Earning with AI</span>
              </h2>
              <p className="section-sub fade-in">A complete beginner-to-earner blueprint — structured to get you results fast.</p>
              <div className="checklist">
                <div className="check-item fade-in">
                  <div className="check-icon">🧠</div>
                  <div className="check-content">
                    <div className="check-title">7 Core AI Skills That Pay</div>
                    <div className="check-desc">The exact skills in highest demand right now — ranked by income potential and ease of entry.</div>
                  </div>
                </div>
                <div className="check-item fade-in">
                  <div className="check-icon">🗺️</div>
                  <div className="check-content">
                    <div className="check-title">Step-by-Step Income Systems</div>
                    <div className="check-desc">Follow-along blueprints that take you from zero to your first AI income stream.</div>
                  </div>
                </div>
                <div className="check-item fade-in">
                  <div className="check-icon">💲</div>
                  <div className="check-content">
                    <div className="check-title">Pricing & Monetization Blueprints</div>
                    <div className="check-desc">Exact pricing frameworks so you never undercharge again. Charge what you're worth.</div>
                  </div>
                </div>
                <div className="check-item fade-in">
                  <div className="check-icon">🎯</div>
                  <div className="check-content">
                    <div className="check-title">Client Acquisition Blueprint</div>
                    <div className="check-desc">Where to find clients, how to pitch them, and how to close without sounding salesy.</div>
                  </div>
                </div>
                <div className="check-item fade-in">
                  <div className="check-icon">📅</div>
                  <div className="check-content">
                    <div className="check-title">7-Day Action Plan</div>
                    <div className="check-desc">A day-by-day roadmap to go from "just downloaded" to actively building income.</div>
                  </div>
                </div>
                <div className="check-item fade-in">
                  <div className="check-icon">📋</div>
                  <div className="check-content">
                    <div className="check-title">Worksheets & Checklists</div>
                    <div className="check-desc">Fillable templates and checklists so you always know your next move.</div>
                  </div>
                </div>
                <div className="check-item fade-in">
                  <div className="check-icon">🔧</div>
                  <div className="check-content">
                    <div className="check-title">Tools & Resources Directory</div>
                    <div className="check-desc">The exact tools used by top AI earners — including free options to get started today.</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="inside-visual fade-in">
              <div className="inside-card-stack">
                <div className="icard">
                  <div className="icard-label">Chapter 01</div>
                  <div className="icard-number">7</div>
                  <div className="icard-text">Core AI Skills</div>
                </div>
                <div className="icard">
                  <div className="icard-label">⭐ Featured</div>
                  <div className="icard-number">10+</div>
                  <div className="icard-text">Income Models</div>
                </div>
                <div className="icard">
                  <div className="icard-label">Bonus</div>
                  <div className="icard-number">7</div>
                  <div className="icard-text">Day Action Plan</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* BENEFITS */}
      <section id="benefits">
        <div className="section-inner">
          <div className="section-label fade-in">Your Transformation</div>
          <h2 className="section-title fade-in">
            From <span className="hl">AI Curious</span> to
            <br />
            <span className="hl-gold">AI Earning</span>
          </h2>
          <p className="section-sub fade-in">This isn't just about learning. It's about changing what's possible for your income.</p>
          <div className="benefits-grid">
            <div className="benefit-item fade-in">
              <div className="benefit-num">01</div>
              <div className="benefit-body">
                <div className="benefit-title">Save Hours Every Single Week</div>
                <div className="benefit-desc">Harness AI to automate repetitive tasks, speed up creation, and reclaim the time you used to lose to manual work.</div>
              </div>
            </div>
            <div className="benefit-item fade-in">
              <div className="benefit-num">02</div>
              <div className="benefit-body">
                <div className="benefit-title">Learn Beginner-Friendly Systems</div>
                <div className="benefit-desc">No coding. No tech background. No prior experience required. Every system is designed to be understood and applied on day one.</div>
              </div>
            </div>
            <div className="benefit-item fade-in">
              <div className="benefit-num">03</div>
              <div className="benefit-body">
                <div className="benefit-title">Start Building Digital Income</div>
                <div className="benefit-desc">Move from consuming content to creating income. The ebook gives you real paths to earning — not hypothetical side hustle ideas.</div>
              </div>
            </div>
            <div className="benefit-item fade-in">
              <div className="benefit-num">04</div>
              <div className="benefit-body">
                <div className="benefit-title">Understand Real AI Workflows</div>
                <div className="benefit-desc">See exactly how professionals chain AI tools together to deliver results clients pay premium rates for.</div>
              </div>
            </div>
            <div className="benefit-item fade-in">
              <div className="benefit-num">05</div>
              <div className="benefit-body">
                <div className="benefit-title">Build Profitable Online Skills</div>
                <div className="benefit-desc">Develop a future-proof skill set that grows more valuable as AI becomes more embedded in every industry.</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* EMAIL CAPTURE */}
      <section id="signup">
        <div className="section-inner">
          <div className="form-container">
            <div className="section-label fade-in" style={{ justifyContent: "center" }}>
              Free Instant Access
            </div>
            <h2 className="section-title fade-in" style={{ textAlign: "center" }}>
              Get Your Free Copy
              <br />
              of the <span className="hl-gold">AI Income Ebook</span>
            </h2>
            <p style={{ textAlign: "center", color: "var(--muted)", fontSize: "15px", lineHeight: "1.7" }} className="fade-in">
              Join thousands of beginners, students, and digital entrepreneurs already using these AI systems.
            </p>
            <div className="form-box fade-in">
              {!isSuccess ? (
                <div id="formContent">
                  <div className="form-title">🔐 Claim Your Free Ebook</div>
                  <div className="form-sub">Enter your details below and get instant access. We'll also send you weekly AI income tips.</div>
                  <div id="signupForm">
                    <div className="form-group">
                      <label htmlFor="firstName">First Name</label>
                      <input
                        type="text"
                        id="firstName"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="Your first name"
                        autoComplete="given-name"
                      />
                    </div>
                    <div className="form-group">
                      <label htmlFor="email">Email Address</label>
                      <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="your@email.com"
                        autoComplete="email"
                      />
                    </div>
                    <button className="btn-submit" id="submitBtn" onClick={() => handleSubmit()} disabled={isSubmitting}>
                      {isSubmitting ? "⏳ Setting Up Your Access..." : "⚡ Download The Free Ebook"}
                    </button>
                  </div>
                  <p className="form-privacy">🔒 Your information is secure. No spam, ever. Unsubscribe anytime.</p>
                </div>
              ) : (
                <div className="success-message" id="successMsg">
                  <div className="success-icon">🎉</div>
                  <div className="success-title">Welcome to the AI Income System!</div>
                  <div className="success-sub">Check your inbox right now — your ebook is on its way. Here's what happens next:</div>
                  <div className="success-steps">
                    <div className="sstep">
                      <span className="sstep-icon">📧</span> Welcome email + ebook download link sent to your inbox
                    </div>
                    <div className="sstep">
                      <span className="sstep-icon">📘</span> Your AI Income System ebook is ready to read
                    </div>
                    <div className="sstep">
                      <span className="sstep-icon">🚀</span> AI tips, tools & income strategies coming over the next 7 days
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* EMAIL SEQUENCE */}
      <section id="sequence">
        <div className="section-inner">
          <div className="section-label fade-in">Email Automation</div>
          <h2 className="section-title fade-in">
            What Happens After
            <br />
            You <span className="hl">Sign Up</span>
          </h2>
          <p className="section-sub fade-in">We've built a complete AI income journey — delivered directly to your inbox over 7 days.</p>
          <div className="sequence-line">
            <div className="seq-item fade-in">
              <div className="seq-dot active">01</div>
              <div className="seq-content">
                <div className="seq-timing">Immediately → Day 0</div>
                <div className="seq-title">🎁 Welcome + Ebook Delivery</div>
                <div className="seq-desc">Your free ebook arrives instantly. A warm welcome walks you through what's inside and how to get the most value in the shortest time.</div>
                <span className="seq-tag delivery">INSTANT DELIVERY</span>
              </div>
            </div>
            <div className="seq-item fade-in">
              <div className="seq-dot">02</div>
              <div className="seq-content">
                <div className="seq-timing">Day 2</div>
                <div className="seq-title">🛠️ Top AI Tools Beginners Should Start Using</div>
                <div className="seq-desc">A curated breakdown of the best free and low-cost AI tools — the exact ones earning creators and freelancers use daily in 2026.</div>
                <span className="seq-tag value">PURE VALUE</span>
              </div>
            </div>
            <div className="seq-item fade-in">
              <div className="seq-dot">03</div>
              <div className="seq-content">
                <div className="seq-timing">Day 4</div>
                <div className="seq-title">💡 How People Are Making Money With AI</div>
                <div className="seq-desc">Real-world income case studies — how beginners are earning from content creation, freelancing, digital products, and AI automation services.</div>
                <span className="seq-tag value">CASE STUDIES</span>
              </div>
            </div>
            <div className="seq-item fade-in">
              <div className="seq-dot">04</div>
              <div className="seq-content">
                <div className="seq-timing">Day 7</div>
                <div className="seq-title">🚀 Your Next Step: Go Deeper</div>
                <div className="seq-desc">For those ready to accelerate — an exclusive look at premium resources, tools, and communities designed to fast-track your AI income journey.</div>
                <span className="seq-tag promo">UPGRADE OFFER</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="divider"></div>

      {/* SOCIAL PROOF */}
      <section id="proof">
        <div className="section-inner">
          <div className="section-label fade-in">Social Proof</div>
          <h2 className="section-title fade-in">
            Real People. <span className="hl">Real Results.</span>
          </h2>
          <p className="section-sub fade-in">Thousands of beginners have already downloaded the ebook and started their AI income journey.</p>
          <div className="testimonials">
            <div className="tcard fade-in">
              <div className="tcard-stars">★★★★★</div>
              <div className="tcard-quote">"</div>
              <div className="tcard-text">I had zero experience with AI. After reading this ebook I landed my first freelance AI writing client within 2 weeks. The client acquisition blueprint alone was worth everything.</div>
              <div className="tcard-author">
                <div className="tcard-avatar">👩</div>
                <div>
                  <div className="tcard-name">Sarah M.</div>
                  <div className="tcard-role">Freelance Content Creator · UK</div>
                </div>
              </div>
            </div>
            <div className="tcard fade-in">
              <div className="tcard-stars">★★★★★</div>
              <div className="tcard-quote">"</div>
              <div className="tcard-text">As a student with no budget, this was exactly what I needed. The free tools section helped me start a digital product business using AI. Already made back 10x in digital sales.</div>
              <div className="tcard-author">
                <div className="tcard-avatar">👨</div>
                <div>
                  <div className="tcard-name">James K.</div>
                  <div className="tcard-role">University Student · Canada</div>
                </div>
              </div>
            </div>
            <div className="tcard fade-in">
              <div className="tcard-stars">★★★★★</div>
              <div className="tcard-quote">"</div>
              <div className="tcard-text">The automation workflows chapter blew my mind. I built a content system that now runs on autopilot and generates leads for my agency. This ebook is criminally underpriced at free.</div>
              <div className="tcard-author">
                <div className="tcard-avatar">🧑</div>
                <div>
                  <div className="tcard-name">Marcus T.</div>
                  <div className="tcard-role">Digital Agency Owner · USA</div>
                </div>
              </div>
            </div>
            <div className="tcard fade-in">
              <div className="tcard-stars">★★★★★</div>
              <div className="tcard-quote">"</div>
              <div className="tcard-text">I was skeptical about another "make money online" ebook. But this was completely different — real systems, real tools, and a 7-day plan that I actually followed. Highly recommend.</div>
              <div className="tcard-author">
                <div className="tcard-avatar">👩</div>
                <div>
                  <div className="tcard-name">Priya R.</div>
                  <div className="tcard-role">Social Media Creator · India</div>
                </div>
              </div>
            </div>
            <div className="tcard fade-in">
              <div className="tcard-stars">★★★★★</div>
              <div className="tcard-quote">"</div>
              <div className="tcard-text">The pricing blueprints changed how I think about my services. I raised my rates by 3x after understanding the value framing explained in this guide. Life-changing stuff.</div>
              <div className="tcard-author">
                <div className="tcard-avatar">👨</div>
                <div>
                  <div className="tcard-name">Alex V.</div>
                  <div className="tcard-role">AI Consultant · Germany</div>
                </div>
              </div>
            </div>
            <div className="tcard fade-in">
              <div className="tcard-stars">★★★★★</div>
              <div className="tcard-quote">"</div>
              <div className="tcard-text">Perfect for anyone who wants to start making money with AI but doesn't know where to begin. The step-by-step format made it so easy to take action immediately. Highly recommended!</div>
              <div className="tcard-author">
                <div className="tcard-avatar">🧑</div>
                <div>
                  <div className="tcard-name">Elena W.</div>
                  <div className="tcard-role">Aspiring Entrepreneur · Australia</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section id="finalcta">
        <div className="section-inner">
          <div className="final-inner">
            <div className="section-label fade-in" style={{ justifyContent: "center" }}>
              Last Chance
            </div>
            <h2 className="final-h2 fade-in">
              Start Building Your
              <br />
              <span
                style={{
                  background: "linear-gradient(135deg, var(--gold), var(--gold-light))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                AI Future Today
              </span>
            </h2>
            <p className="final-sub fade-in">
              The AI economy is growing faster than any job market in history. The skills you build today could define your financial future for the next decade.
            </p>
            <a href="#signup" onClick={(e) => scrollToSection(e, "#signup")} className="btn-final fade-in">
              ⚡ Get Instant Access Now <span>→</span>
            </a>
            <p className="final-note fade-in">Free · No credit card · Instant download · No experience required</p>
            <div className="final-features fade-in">
              <div className="ff-item">
                <span className="ff-check">✓</span> 7 Core AI Skills
              </div>
              <div className="ff-item">
                <span className="ff-check">✓</span> Monetization Blueprints
              </div>
              <div className="ff-item">
                <span className="ff-check">✓</span> 7-Day Action Plan
              </div>
              <div className="ff-item">
                <span className="ff-check">✓</span> Tools Directory
              </div>
              <div className="ff-item">
                <span className="ff-check">✓</span> Email Automation
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer>
        <div className="footer-logo">AI Income System © 2026</div>
        <div className="footer-links">
          <a href="#">Privacy Policy</a>
          <a href="#">Terms of Use</a>
          <a href="#">Contact</a>
        </div>
        <div className="footer-copy">Powered by AI. Built for Humans.</div>
      </footer>
    </>
  );
}
